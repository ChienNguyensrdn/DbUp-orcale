﻿CREATE OR REPLACE PACKAGE PKG_COMMON_LIST IS

  TYPE CURSOR_TYPE IS REF CURSOR;

  PROCEDURE GET_TABLES(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_COLUMNS(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_OTHER_LIST(P_TYPE    IN NVARCHAR2,
                           P_ISBLANK IN NUMBER,
                           P_LANG    IN VARCHAR,
                           P_CUR     OUT CURSOR_TYPE);
                           
  PROCEDURE GET_LIST_INSURANCE(P_STRUCT    IN NVARCHAR2,
                           P_CUR     OUT CURSOR_TYPE);
                           
  PROCEDURE GET_LIST_INS_REGION(P_STRUCT    IN NVARCHAR2,
                           P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_ORG_LEVEL (P_STRUCT    IN NVARCHAR2,
                           P_CUR     OUT CURSOR_TYPE);    
  PROCEDURE GET_ALL_BRANCH_ORGLEVEL(P_ORGID IN NUMBER,
                                    P_CUR OUT CURSOR_TYPE);                      
  
  PROCEDURE CREATE_NEW_EMPCODE(P_CUR OUT CURSOR_TYPE);
  
  PROCEDURE GET_TR_CENTER(P_ISBLANK IN NUMBER,
                          P_LANG    IN VARCHAR,
                          P_CUR     OUT CURSOR_TYPE);
  PROCEDURE GET_PA_SAL_TYPE(P_ISBLANK IN NUMBER,
                             P_DATE    IN DATE,
                             P_CUR     OUT CURSOR_TYPE);
  PROCEDURE GET_PA_SAL_GROUP(P_ISBLANK IN NUMBER,
                             P_DATE    IN DATE,
                             P_CUR     OUT CURSOR_TYPE);
  PROCEDURE GET_PA_SAL_LEVEL(P_ISBLANK      IN NUMBER,
                             P_SAL_GROUP_ID IN NUMBER,
                             P_CUR          OUT CURSOR_TYPE);

  PROCEDURE GET_PA_SAL_RANK(P_ISBLANK      IN NUMBER,
                            P_SAL_LEVEL_ID IN NUMBER,
                            P_CUR          OUT CURSOR_TYPE);

  PROCEDURE GET_TR_PLAN_BY_YEARORG(P_ISBLANK IN NUMBER,
                                   P_YEAR    IN NUMBER,
                                   P_ORGID   IN NUMBER,
                                   P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_TR_PROGRAM_BY_YEAR(P_ISBLANK IN NUMBER,
                                   P_YEAR    IN NUMBER,
                                   P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_TR_CHOOSE_PROGRAM_FORM(P_ISBLANK IN NUMBER,
                                       P_YEAR    IN NUMBER,
                                       P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_TR_CRITERIA_GROUP(P_ISBLANK IN NUMBER,
                                  P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_TR_CERTIFICATE(P_GROUP_ID IN NUMBER,
                               P_ISBLANK  IN NUMBER,
                               P_LANG     IN VARCHAR,
                               P_CUR      OUT CURSOR_TYPE);

  PROCEDURE GET_TR_ASS_FORM(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_NATION(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_INS_REGION(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_PROVINCE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_DISTRICT(P_ISBLANK     IN NUMBER,
                            P_PROVINCE_ID IN NUMBER,
                            P_CUR         OUT CURSOR_TYPE);

  PROCEDURE GET_HU_WARD(P_ISBLANK     IN NUMBER,
                        P_DISTRICT_ID IN NUMBER,
                        P_CUR         OUT CURSOR_TYPE);

  PROCEDURE GET_HU_MERGE_FIELD(P_ISBLANK          IN NUMBER,
                               P_TEMPLATE_TYPE_ID IN NUMBER,
                               P_CUR              OUT CURSOR_TYPE);

  PROCEDURE GET_HU_DATA_DYNAMIC(P_ID               IN NUMBER,
                                P_TEMPLATE_TYPE_ID IN NUMBER,
                                P_FOLDERNAME       OUT NVARCHAR2,
                                P_CUR              OUT CURSOR_TYPE);

  PROCEDURE GET_HU_STAFF_RANK(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_TEMPLATE(P_ISBLANK          IN NUMBER,
                            P_TEMPLATE_TYPE_ID IN NUMBER,
                            P_CUR              OUT CURSOR_TYPE);

  PROCEDURE GET_HU_TEMPLATE_TYPE(P_ISBLANK IN NUMBER,
                                 P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_OT_WAGE_TYPE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_OT_MISSION_TYPE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_OT_TRIPARTITE_TYPE(P_ISBLANK IN NUMBER,
                                   P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_AT_ORG_PERIOD(P_PERIOD IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_PA_OBJ_SALARY(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_BANK(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_BANK_BRANCH(P_ISBLANK IN NUMBER,
                               P_BANK_ID IN NUMBER,
                               P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_CONTRACT_TYPE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_ALLOWANCE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_HU_COMPETENCY_GROUP(P_ISBLANK IN NUMBER,
                                    P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_HU_COMPETENCY(P_GROUP_ID IN NUMBER,
                              P_ISBLANK  IN NUMBER,
                              P_CUR      OUT CURSOR_TYPE);

  PROCEDURE GET_HU_COMPETENCY_PERIOD(P_YEAR    IN NUMBER,
                                     P_ISBLANK IN NUMBER,
                                     P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_REPORT(P_LIKE IN VARCHAR2, P_CUR OUT CURSOR_TYPE);

  PROCEDURE GET_TITLE(P_ISBLANK IN NUMBER,
                      P_LANG    IN VARCHAR,
                      P_CUR     OUT CURSOR_TYPE);

  PROCEDURE GET_TITLE_BYORG(P_ORGID   IN NUMBER,
                            P_ISBLANK IN NUMBER,
                            P_LANG    IN VARCHAR,
                            P_CUR     OUT CURSOR_TYPE);

  PROCEDURE INSERT_CHOSEN_ORG(P_USERNAME   IN NVARCHAR2,
                              P_ORGID      IN NUMBER,
                              P_ISDISSOLVE IN NUMBER);

  PROCEDURE INSERT_CHOSEN_ORG2(P_USERNAME IN VARCHAR2, P_ORG_ID IN CLOB);

  PROCEDURE INSERT_CHOSEN_EMP_3B(P_USERNAME    IN NVARCHAR2,
                                 P_EMPLOYEE_ID IN NUMBER);
  PROCEDURE GET_RC_PROGRAM_EXAMS(P_RC_PROGRAM_ID IN NUMBER,
                                 P_ISBLANK       IN NUMBER,
                                 P_LANG          IN VARCHAR,
                                 P_CUR           OUT CURSOR_TYPE);
                                 
  PROCEDURE GET_TR_COURSE(P_ISBLANK IN NUMBER,
                      P_LANG    IN VARCHAR,
                      P_CUR     OUT CURSOR_TYPE);    
                      
  PROCEDURE GET_HU_DATA_DYNAMIC_CONTRACT(P_ID               IN CLOB,
                                P_TEMPLATE_TYPE_ID IN NUMBER,
                                P_FOLDERNAME       OUT NVARCHAR2,
                                P_CUR              OUT CURSOR_TYPE);                                                 
                                 
END PKG_COMMON_LIST;
/
CREATE OR REPLACE PACKAGE BODY PKG_COMMON_LIST IS

  PROCEDURE GET_TABLES(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT UPPER(TABLE_NAME) TABLE_NAME
          FROM USER_TABLES
         ORDER BY TABLE_NAME;
    ELSE
      OPEN P_CUR FOR
        SELECT NULL TABLE_NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT UPPER(TABLE_NAME) TABLE_NAME
                  FROM USER_TABLES
                 ORDER BY TABLE_NAME);
    END IF;
  END;

  PROCEDURE GET_COLUMNS(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT UPPER(TABLE_NAME) TABLE_NAME,
               UPPER(COLUMN_NAME) COLUMN_NAME,
               UPPER(DATA_TYPE) DATA_TYPE
          FROM USER_TAB_COLUMNS
         ORDER BY TABLE_NAME, COLUMN_NAME;
    ELSE
      OPEN P_CUR FOR
        SELECT NULL TABLE_NAME, NULL COLUMN_NAME, NULL DATA_TYPE
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT UPPER(TABLE_NAME) TABLE_NAME,
                       UPPER(COLUMN_NAME) COLUMN_NAME,
                       UPPER(DATA_TYPE) DATA_TYPE
                  FROM USER_TAB_COLUMNS
                 ORDER BY TABLE_NAME, COLUMN_NAME);
    END IF;
  END;

  PROCEDURE GET_OTHER_LIST(P_TYPE    IN NVARCHAR2,
                           P_ISBLANK IN NUMBER,
                           P_LANG    IN VARCHAR,
                           P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID,
               L.CODE,
               DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME,
               L.ATTRIBUTE1,
               L.ATTRIBUTE2,
               L.ATTRIBUTE3,
               L.ATTRIBUTE4
          FROM OT_OTHER_LIST L
         INNER JOIN OT_OTHER_LIST_TYPE T
            ON L.TYPE_ID = T.ID
           AND T.CODE = P_TYPE
           AND L.ACTFLG = 'A'
         ORDER BY NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese'), L.CODE;
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID,
               NULL CODE,
               NULL NAME,
               NULL ATTRIBUTE1,
               NULL ATTRIBUTE2,
               NULL ATTRIBUTE3,
               NULL ATTRIBUTE4
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID,
                       L.CODE,
                       DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME,
                       L.ATTRIBUTE1,
                       L.ATTRIBUTE2,
                       L.ATTRIBUTE3,
                       L.ATTRIBUTE4
                  FROM OT_OTHER_LIST L
                 INNER JOIN OT_OTHER_LIST_TYPE T
                    ON L.TYPE_ID = T.ID
                   AND T.CODE = P_TYPE
                   AND L.ACTFLG = 'A'
                 ORDER BY NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese'), L.CODE);
    END IF;
  END;

   PROCEDURE GET_LIST_INS_REGION(P_STRUCT    IN NVARCHAR2,
                           P_CUR     OUT CURSOR_TYPE)IS
   BEGIN
     OPEN P_CUR FOR
     SELECT 
          R.ID,
          R.REGION_CODE,
          R.REGION_NAME,
          R.NOTE,
          R.ACTFLG
     FROM INS_REGION R
     WHERE R.ACTFLG='A'
     AND P_STRUCT='1';
   END;


  --Create by: ChienNV;Create date:11/10/2017;L?y danh s�ch don v? d�ng b?o hi?m
  PROCEDURE GET_LIST_INSURANCE(P_STRUCT    IN NVARCHAR2,
                           P_CUR     OUT CURSOR_TYPE)IS
  BEGIN
    OPEN P_CUR FOR
    SELECT 
         id           
         ,code         
         ,name         
         ,address      
         ,treatmentcode
         ,phone_number 
         ,status       
         ,created_by   
         ,created_date 
         ,modified_by  
         ,modified_date
         ,created_log  
         ,modified_log 
         ,provincecode 
         ,note         
         ,is_deleted   
    FROM INS_LIST_INSURANCE
    WHERE P_STRUCT='1';
  END;
  
  PROCEDURE GET_ORG_LEVEL (P_STRUCT    IN NVARCHAR2,
                           P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    OPEN P_CUR FOR
    SELECT 
         L.ID,
         L.NAME_VN,
         L.CODE
    FROM OT_OTHER_LIST L
    INNER JOIN OT_OTHER_LIST_TYPE T ON L.TYPE_ID=T.ID
    WHERE T.CODE='ORG_LEVEL'
    AND L.ACTFLG='A'
    AND P_STRUCT='1';
  END;

 PROCEDURE GET_ALL_BRANCH_ORGLEVEL(P_ORGID IN NUMBER,
                                    P_CUR OUT CURSOR_TYPE)IS
 PV_COUNT NUMBER:=0;
 PV_ORGID NUMBER:=0;
 BEGIN
   DELETE FROM TEMP_ORG_BRANCH;
   COMMIT;
   PV_ORGID:=P_ORGID;
   LOOP
     INSERT INTO TEMP_ORG_BRANCH(ID,NAME,LEVEL_ORG,CODE,REPRESENTATIVE_ID,REPRESENTATIVE_NAME)
     SELECT 
            O.ID,
            O.NAME_VN AS NAME,
            T.CODE,
            DECODE(T.CODE,1,'CTY','2','BP',3,'PHONG',4,'BAN',5,'TO') AS LEVEL_ORG,
            E.ID,
            E.FULLNAME_VN 
     FROM HU_ORGANIZATION O
     LEFT JOIN HU_EMPLOYEE E ON O.REPRESENTATIVE_ID=E.ID 
     LEFT JOIN OT_OTHER_LIST T ON O.ORG_LEVEL=T.ID
     LEFT JOIN OT_OTHER_LIST_TYPE OT ON OT.ID=T.TYPE_ID
     WHERE O.ID=PV_ORGID
     AND O.ACTFLG='A'
     AND O.ORG_LEVEL <> 0 AND O.ORG_LEVEL IS NOT NULL
     AND OT.CODE='ORG_LEVEL'
     AND T.ACTFLG='A';
     COMMIT;
     SELECT 
         NVL(O.PARENT_ID,0)
     INTO PV_ORGID
     FROM HU_ORGANIZATION O
     WHERE O.ID=PV_ORGID;
     PV_COUNT:=PV_COUNT+1;
     IF PV_COUNT>5 OR PV_ORGID=0  THEN
       EXIT;
     END IF;
     
     --EXIT WHEN PV_ORGID =0;
     END LOOP;
   OPEN P_CUR FOR
   SELECT * FROM TEMP_ORG_BRANCH;
   END;
 
 PROCEDURE CREATE_NEW_EMPCODE(P_CUR OUT CURSOR_TYPE) IS
   PV_EMP_CODE NVARCHAR2(4):='';
   PV_COUNT INTEGER:=1;
   PV_CHECK_EXIT INTEGER:=0;
 BEGIN
   LOOP
    SELECT 
      substr('E00',LENGTH(TO_CHAR (TO_NUMBER( NVL(substr(MAX(S.CODES),2),'000'))+PV_COUNT)))||
      TO_CHAR(TO_NUMBER( NVL(substr(MAX(S.CODES),2),'000'))+PV_COUNT)
    INTO PV_EMP_CODE
    FROM SPACE_EMP_CODE S;
    
    --KI�M TRA T?N T?I EMP_CODE 
    SELECT COUNT(*)
    INTO PV_CHECK_EXIT
    FROM HU_EMPLOYEE E
    WHERE E.EMPLOYEE_CODE=PV_EMP_CODE;
    IF PV_CHECK_EXIT=0 OR PV_COUNT >100 THEN
      INSERT INTO SPACE_EMP_CODE(IDS,CODES,COMMENTS)
      SELECT 
             SEQ_SPACE_EMP_CODE.NEXTVAL,
             PV_EMP_CODE,
             ''
      FROM DUAL;
      COMMIT;
      EXIT;
    END IF;
    PV_COUNT:=PV_COUNT+1;
   END LOOP;
   
   
   OPEN P_CUR FOR
   SELECT PV_EMP_CODE
   FROM DUAL;
   END;
 
 PROCEDURE GET_TR_CENTER(P_ISBLANK IN NUMBER,
                          P_LANG    IN VARCHAR,
                          P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME
          FROM TR_CENTER L
         WHERE L.ACTFLG = -1
         ORDER BY NLSSORT(DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN),
                          'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID,
                       DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME
                  FROM TR_CENTER L
                 WHERE L.ACTFLG = -1
                 ORDER BY NLSSORT(DECODE(P_LANG,
                                         'vi-VN',
                                         L.NAME_VN,
                                         L.NAME_EN),
                                  'NLS_SORT=vietnamese'));
    END IF;
  END;
PROCEDURE GET_PA_SAL_TYPE(P_ISBLANK IN NUMBER,
                             P_DATE    IN DATE,
                             P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.Name
          FROM PA_SALARY_TYPE L
         WHERE L.IS_INCENTIVE =0 and l.actflg='A'
         ORDER BY L.ORDERS ASC;
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.Name
          FROM PA_SALARY_TYPE L
         WHERE L.IS_INCENTIVE =0 and l.actflg='A'
         ORDER BY L.ORDERS ASC);
    END IF;
  END;

  PROCEDURE GET_PA_SAL_GROUP(P_ISBLANK IN NUMBER,
                             P_DATE    IN DATE,
                             P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM PA_SALARY_GROUP L
         WHERE L.EFFECT_DATE <= P_DATE
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
                  FROM PA_SALARY_GROUP L
                 WHERE L.EFFECT_DATE <= P_DATE
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_PA_SAL_LEVEL(P_ISBLANK      IN NUMBER,
                             P_SAL_GROUP_ID IN NUMBER,
                             P_CUR          OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM PA_SALARY_LEVEL L
         WHERE L.SAL_GROUP_ID = P_SAL_GROUP_ID
           AND L.ACTFLG = 'A'
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
                  FROM PA_SALARY_LEVEL L
                 WHERE L.SAL_GROUP_ID = P_SAL_GROUP_ID
                   AND L.ACTFLG = 'A'
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_PA_SAL_RANK(P_ISBLANK      IN NUMBER,
                            P_SAL_LEVEL_ID IN NUMBER,
                            P_CUR          OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.RANK NAME, L.SALARY_BASIC
          FROM PA_SALARY_RANK L
         WHERE L.SAL_LEVEL_ID = P_SAL_LEVEL_ID
           AND L.ACTFLG = 'A'
         ORDER BY NLSSORT(L.RANK, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME, NULL SALARY_BASIC
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.RANK, L.SALARY_BASIC
                  FROM PA_SALARY_RANK L
                 WHERE L.SAL_LEVEL_ID = P_SAL_LEVEL_ID
                   AND L.ACTFLG = 'A'
                 ORDER BY NLSSORT(L.RANK, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_TR_PLAN_BY_YEARORG(P_ISBLANK IN NUMBER,
                                   P_YEAR    IN NUMBER,
                                   P_ORGID   IN NUMBER,
                                   P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, COU.NAME || ' - ' || E.NAME NAME
          FROM TR_PLAN E
         INNER JOIN TR_COURSE COU
            ON E.TR_COURSE_ID = COU.ID
         WHERE E.YEAR = P_YEAR
           AND E.ORG_ID = P_ORGID
         ORDER BY NLSSORT(COU.NAME || ' - ' || E.NAME,
                          'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, COU.NAME || ' - ' || E.NAME NAME
                  FROM TR_PLAN E
                 INNER JOIN TR_COURSE COU
                    ON E.TR_COURSE_ID = COU.ID
                 WHERE E.YEAR = P_YEAR
                   AND E.ORG_ID = P_ORGID
                 ORDER BY NLSSORT(COU.NAME || ' - ' || E.NAME,
                                  'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_TR_PROGRAM_BY_YEAR(P_ISBLANK IN NUMBER,
                                   P_YEAR    IN NUMBER,
                                   P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, COU.NAME || ' - ' || E.NAME NAME
          FROM TR_PROGRAM E
         INNER JOIN TR_COURSE COU
            ON E.TR_COURSE_ID = COU.ID
         WHERE E.YEAR = P_YEAR
           AND NVL(E.IS_REIMBURSE, 0) = -1
         ORDER BY NLSSORT(COU.NAME || ' - ' || E.NAME,
                          'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, COU.NAME || ' - ' || E.NAME NAME
                  FROM TR_PROGRAM E
                 INNER JOIN TR_COURSE COU
                    ON E.TR_COURSE_ID = COU.ID
                 WHERE E.YEAR = P_YEAR
                   AND NVL(E.IS_REIMBURSE, 0) = -1
                 ORDER BY NLSSORT(COU.NAME || ' - ' || E.NAME,
                                  'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_TR_CHOOSE_PROGRAM_FORM(P_ISBLANK IN NUMBER,
                                       P_YEAR    IN NUMBER,
                                       P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT FORM.ID, COU.NAME || ' - ' || E.NAME NAME
          FROM TR_PROGRAM E
         INNER JOIN TR_COURSE COU
            ON E.TR_COURSE_ID = COU.ID
         INNER JOIN TR_CHOOSE_FORM FORM
            ON FORM.TR_PROGRAM_ID = E.ID
         WHERE E.YEAR = P_YEAR
         ORDER BY NLSSORT(COU.NAME || ' - ' || E.NAME,
                          'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT FORM.ID, COU.NAME || ' - ' || E.NAME NAME
                  FROM TR_PROGRAM E
                 INNER JOIN TR_COURSE COU
                    ON E.TR_COURSE_ID = COU.ID
                 INNER JOIN TR_CHOOSE_FORM FORM
                    ON FORM.TR_PROGRAM_ID = E.ID
                 WHERE E.YEAR = P_YEAR
                 ORDER BY NLSSORT(COU.NAME || ' - ' || E.NAME,
                                  'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_TR_CRITERIA_GROUP(P_ISBLANK IN NUMBER,
                                  P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.CODE || ' - ' || L.NAME NAME
          FROM TR_CRITERIA_GROUP L
         WHERE L.ACTFLG = -1
         ORDER BY NLSSORT(L.CODE || ' - ' || L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.CODE || ' - ' || L.NAME NAME
                  FROM TR_CRITERIA_GROUP L
                 WHERE L.ACTFLG = -1
                 ORDER BY NLSSORT(L.CODE || ' - ' || L.NAME,
                                  'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_TR_CERTIFICATE(P_GROUP_ID IN NUMBER,
                               P_ISBLANK  IN NUMBER,
                               P_LANG     IN VARCHAR,
                               P_CUR      OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME
          FROM TR_CERTIFICATE L
         WHERE L.ACTFLG = -1
           AND L.TR_CER_GROUP_ID = P_GROUP_ID
         ORDER BY NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID,
                       DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME
                  FROM TR_CERTIFICATE L
                 WHERE L.ACTFLG = -1
                   AND L.TR_CER_GROUP_ID = P_GROUP_ID
                 ORDER BY NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_TR_ASS_FORM(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM TR_ASSESSMENT_FORM L
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
                  FROM TR_ASSESSMENT_FORM L
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_NATION(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME_VN NAME
          FROM HU_NATION E
         WHERE E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME_VN
                  FROM HU_NATION E
                 WHERE E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_INS_REGION(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.REGION_NAME NAME
          FROM INS_REGION E
         WHERE E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.REGION_NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.REGION_NAME
                  FROM INS_REGION E
                 WHERE E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.REGION_NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_PROVINCE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME_VN NAME
          FROM HU_PROVINCE E
         WHERE E.NATION_ID = 1
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME_VN
                  FROM HU_PROVINCE E
                 WHERE E.NATION_ID = 1
                   AND E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_DISTRICT(P_ISBLANK     IN NUMBER,
                            P_PROVINCE_ID IN NUMBER,
                            P_CUR         OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME_VN NAME
          FROM HU_DISTRICT E
         WHERE E.PROVINCE_ID = P_PROVINCE_ID
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME_VN
                  FROM HU_DISTRICT E
                 WHERE E.PROVINCE_ID = P_PROVINCE_ID
                   AND E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_WARD(P_ISBLANK     IN NUMBER,
                        P_DISTRICT_ID IN NUMBER,
                        P_CUR         OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME_VN NAME
          FROM HU_WARD E
         WHERE E.DISTRICT_ID = P_DISTRICT_ID
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME_VN NAME
                  FROM HU_WARD E
                 WHERE E.DISTRICT_ID = P_DISTRICT_ID
                   AND E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_STAFF_RANK(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME
          FROM HU_STAFF_RANK E
         WHERE E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME
                  FROM HU_STAFF_RANK E
                 WHERE E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_OT_WAGE_TYPE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME_VN NAME
          FROM OT_OTHER_LIST L
         INNER JOIN OT_OTHER_LIST_TYPE T
            ON L.TYPE_ID = T.ID
           AND T.CODE = 'DECISION_TYPE'
           AND L.ACTFLG = 'A'
           AND L.CODE LIKE 'HSL_%'
         ORDER BY L.CODE, NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME_VN NAME
                  FROM OT_OTHER_LIST L
                 INNER JOIN OT_OTHER_LIST_TYPE T
                    ON L.TYPE_ID = T.ID
                   AND T.CODE = 'DECISION_TYPE'
                   AND L.ACTFLG = 'A'
                   AND L.CODE LIKE 'HSL_%'
                 ORDER BY L.CODE, NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_OT_TRIPARTITE_TYPE(P_ISBLANK IN NUMBER,
                                   P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME_VN NAME
          FROM OT_OTHER_LIST L
         INNER JOIN OT_OTHER_LIST_TYPE T
            ON L.TYPE_ID = T.ID
           AND T.CODE = 'DECISION_TYPE'
           AND L.ACTFLG = 'A'
           AND L.CODE = 'CT_05'
         ORDER BY L.CODE, NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME_VN NAME
                  FROM OT_OTHER_LIST L
                 INNER JOIN OT_OTHER_LIST_TYPE T
                    ON L.TYPE_ID = T.ID
                   AND T.CODE = 'DECISION_TYPE'
                   AND L.ACTFLG = 'A'
                   AND L.CODE = 'CT_05'
                 ORDER BY L.CODE, NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_AT_ORG_PERIOD(P_PERIOD IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    OPEN P_CUR FOR
      SELECT T.ORG_ID,
             NVL(T.STATUSCOLEX, -1) STATUSCOLEX,
             NVL(T.STATUSPAROX, -1) STATUSPAROX
        FROM AT_ORG_PERIOD T
       WHERE T.PERIOD_ID = P_PERIOD;
  
  END;

  PROCEDURE GET_OT_MISSION_TYPE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME_VN NAME
          FROM OT_OTHER_LIST L
         INNER JOIN OT_OTHER_LIST_TYPE T
            ON L.TYPE_ID = T.ID
           AND T.CODE = 'DECISION_TYPE'
           AND L.CODE LIKE 'CT_%'
           AND L.ACTFLG = 'A'
         ORDER BY L.CODE, NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME_VN NAME
                  FROM OT_OTHER_LIST L
                 INNER JOIN OT_OTHER_LIST_TYPE T
                    ON L.TYPE_ID = T.ID
                   AND T.CODE = 'DECISION_TYPE'
                   AND L.CODE LIKE 'CT_%'
                   AND L.ACTFLG = 'A'
                 ORDER BY L.CODE, NLSSORT(L.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_PA_OBJ_SALARY(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME_VN NAME
          FROM PA_OBJECT_SALARY E
         WHERE E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME_VN NAME
                  FROM PA_OBJECT_SALARY E
                 WHERE E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_BANK(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME
          FROM HU_BANK E
         WHERE E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME
                  FROM HU_BANK E
                 WHERE E.ACTFLG = 'A'
                 ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_TEMPLATE_TYPE(P_ISBLANK IN NUMBER,
                                 P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME, E.FOLDER_NAME
          FROM HU_TEMPLATE_TYPE E
         ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME, NULL FOLDER_NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME, E.FOLDER_NAME
                  FROM HU_TEMPLATE_TYPE E
                 ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_DATA_DYNAMIC(P_ID               IN NUMBER,
                                P_TEMPLATE_TYPE_ID IN NUMBER,
                                P_FOLDERNAME       OUT NVARCHAR2,
                                P_CUR              OUT CURSOR_TYPE) IS
    PV_VIEWNAME   VARCHAR2(255);
    PV_FOLDERNAME VARCHAR2(255);
  BEGIN
    SELECT E.FOLDER_NAME, E.VIEW_NAME
      INTO PV_FOLDERNAME, PV_VIEWNAME
      FROM HU_TEMPLATE_TYPE E
     WHERE E.ID = P_TEMPLATE_TYPE_ID;
    P_FOLDERNAME := TO_CHAR(PV_FOLDERNAME);
    OPEN P_CUR FOR 'SELECT * FROM ' || PV_VIEWNAME || ' WHERE ID = ' || P_ID;
  
  END;

  PROCEDURE GET_HU_MERGE_FIELD(P_ISBLANK          IN NUMBER,
                               P_TEMPLATE_TYPE_ID IN NUMBER,
                               P_CUR              OUT CURSOR_TYPE) IS
    PV_FOLDERNAME VARCHAR2(255);
    PV_VIEWNAME   VARCHAR2(255);
  BEGIN
    SELECT E.FOLDER_NAME, E.VIEW_NAME
      INTO PV_FOLDERNAME, PV_VIEWNAME
      FROM HU_TEMPLATE_TYPE E
     WHERE E.ID = P_TEMPLATE_TYPE_ID;
  
    OPEN P_CUR FOR
      SELECT E.ID,
             P_TEMPLATE_TYPE_ID TEMPLATE_TYPE_ID,
             VIEW_COLUMN.COLUMN_NAME CODE,
             NVL(E.NAME, VIEW_COLUMN.COLUMN_NAME) NAME,
             PV_FOLDERNAME FOLDER_NAME
        FROM (SELECT VIEW_COLUMN.COLUMN_NAME
                FROM USER_TAB_COLUMNS VIEW_COLUMN
               WHERE VIEW_COLUMN.TABLE_NAME = PV_VIEWNAME
                 AND VIEW_COLUMN.COLUMN_NAME <> 'ID') VIEW_COLUMN
        LEFT JOIN (SELECT E.ID, E.CODE, E.NAME
                     FROM HU_MERGE_FIELD E
                    WHERE HU_TEMPLATE_TYPE_ID = P_TEMPLATE_TYPE_ID) E
          ON VIEW_COLUMN.COLUMN_NAME = E.CODE
       ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese');
  
  END;

  PROCEDURE GET_HU_TEMPLATE(P_ISBLANK          IN NUMBER,
                            P_TEMPLATE_TYPE_ID IN NUMBER,
                            P_CUR              OUT CURSOR_TYPE) IS
  BEGIN
    -- Loai hop dong
    IF P_TEMPLATE_TYPE_ID = 1 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME, TYPE.FOLDER_NAME
          FROM HU_CONTRACT_TYPE E
         INNER JOIN HU_TEMPLATE_TYPE TYPE
            ON TYPE.ID = P_TEMPLATE_TYPE_ID
         WHERE E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese');
    END IF;
  
    -- To trinh/QD
    IF P_TEMPLATE_TYPE_ID = 2 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'DECISION_TYPE'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
    -- Ky luat    
    IF P_TEMPLATE_TYPE_ID = 3 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'DISCIPLINE_PRINT'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
    -- Nghi viec   
    IF P_TEMPLATE_TYPE_ID = 4 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'TERMINATE_PRINT'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
    -- Nghi viec 3B
    IF P_TEMPLATE_TYPE_ID = 5 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'TERMINATE3B_PRINT'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
    -- Hop dong ho tro in
    IF P_TEMPLATE_TYPE_ID = 6 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'CONTRACT_SUPPORT'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
    -- to trinh/quyet dinh ho tro in
    IF P_TEMPLATE_TYPE_ID = 7 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'DECISION_SUPPORT'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
    -- ky luat ho tro in
    IF P_TEMPLATE_TYPE_ID = 8 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'DISCIPLINE_SUPPORT'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
    -- nghi viec ho tro in
    IF P_TEMPLATE_TYPE_ID = 9 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.CODE, E.NAME_VN NAME, TYPE1.FOLDER_NAME
          FROM OT_OTHER_LIST E
         INNER JOIN OT_OTHER_LIST_TYPE TYPE
            ON E.TYPE_ID = TYPE.ID
         INNER JOIN HU_TEMPLATE_TYPE TYPE1
            ON TYPE1.ID = P_TEMPLATE_TYPE_ID
         WHERE TYPE.CODE = 'TERMINATE_SUPPORT'
           AND E.ACTFLG = 'A'
         ORDER BY NLSSORT(E.NAME_VN, 'NLS_SORT=vietnamese');
    END IF;
  
  END;

  PROCEDURE GET_HU_BANK_BRANCH(P_ISBLANK IN NUMBER,
                               P_BANK_ID IN NUMBER,
                               P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT E.ID, E.NAME
          FROM HU_BANK_BRANCH E
         WHERE E.ACTFLG = 'A'
           AND E.BANK_ID = P_BANK_ID
         ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT E.ID, E.NAME
                  FROM HU_BANK_BRANCH E
                 WHERE E.ACTFLG = 'A'
                   AND E.BANK_ID = P_BANK_ID
                 ORDER BY NLSSORT(E.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_CONTRACT_TYPE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM HU_CONTRACT_TYPE L
         WHERE L.ACTFLG = 'A'
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
                  FROM HU_CONTRACT_TYPE L
                 WHERE L.ACTFLG = 'A'
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_ALLOWANCE(P_ISBLANK IN NUMBER, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME, L.IS_INSURANCE
          FROM HU_ALLOWANCE_LIST L
         WHERE L.ACTFLG = 'A'
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME, null IS_INSURANCE
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME, L.IS_INSURANCE
                  FROM HU_ALLOWANCE_LIST L
                 WHERE L.ACTFLG = 'A'
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_HU_COMPETENCY_GROUP(P_ISBLANK IN NUMBER,
                                 P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM HU_COMPETENCY_GROUP L
         WHERE L.ACTFLG = 'A'
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
                  FROM HU_COMPETENCY_GROUP L
                 WHERE L.ACTFLG = 'A'
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

PROCEDURE GET_HU_COMPETENCY_PERIOD(P_YEAR    IN NUMBER,
                                     P_ISBLANK IN NUMBER,
                                     P_CUR     OUT CURSOR_TYPE) IS 
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM HU_COMPETENCY_PERIOD L
         WHERE l.YEAR = P_YEAR
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
          FROM HU_COMPETENCY_PERIOD L
         WHERE l.YEAR = P_YEAR
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;
  
  PROCEDURE GET_HU_COMPETENCY(P_GROUP_ID IN NUMBER,
                           P_ISBLANK  IN NUMBER,
                           P_CUR      OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM HU_COMPETENCY L
         WHERE L.ACTFLG = 'A'
           AND L.COMPETENCY_GROUP_ID = P_GROUP_ID
         ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
                  FROM HU_COMPETENCY L
                 WHERE L.ACTFLG = 'A'
                   AND L.COMPETENCY_GROUP_ID = P_GROUP_ID
                 ORDER BY NLSSORT(L.NAME, 'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_REPORT(P_LIKE IN VARCHAR2, P_CUR OUT CURSOR_TYPE) IS
  BEGIN
    OPEN P_CUR FOR
      SELECT R.ID, R.CODE, R.NAME
        FROM SE_REPORT R
       WHERE R.CODE LIKE '%' || P_LIKE || '%'
       ORDER BY R.CODE;
  END;
  PROCEDURE GET_TITLE(P_ISBLANK IN NUMBER,
                      P_LANG    IN VARCHAR,
                      P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME
          FROM HU_TITLE L
         WHERE L.ACTFLG = 'A'
         ORDER BY NLSSORT(DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN),
                          'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID,
                       DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME
                  FROM HU_TITLE L
                 WHERE L.ACTFLG = 'A'
                 ORDER BY NLSSORT(DECODE(P_LANG,
                                         'vi-VN',
                                         L.NAME_VN,
                                         L.NAME_EN),
                                  'NLS_SORT=vietnamese'));
    END IF;
  END;

  PROCEDURE GET_TITLE_BYORG(P_ORGID   IN NUMBER,
                            P_ISBLANK IN NUMBER,
                            P_LANG    IN VARCHAR,
                            P_CUR     OUT CURSOR_TYPE) IS
    P_ORG_ID2 NUMBER;
  BEGIN
    SELECT ORG_ID2
      INTO P_ORG_ID2
      FROM HUV_ORGANIZATION E
     WHERE E.ID = P_ORGID;
  
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID,
               DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME,
               GRP.NAME_VN GROUP_NAME
          FROM HU_TITLE L
         INNER JOIN HU_ORG_TITLE O
            ON O.TITLE_ID = L.ID
          LEFT JOIN OT_OTHER_LIST GRP
            ON L.TITLE_GROUP_ID = GRP.ID
         WHERE L.ACTFLG = 'A'
           AND O.ACTFLG = 'A'
           AND O.ORG_ID = P_ORG_ID2
         ORDER BY NLSSORT(DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN),
                          'NLS_SORT=vietnamese');
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME, NULL GROUP_NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID,
                       DECODE(P_LANG, 'vi-VN', L.NAME_VN, L.NAME_EN) NAME,
                       GRP.NAME_VN GROUP_NAME
                  FROM HU_TITLE L
                 INNER JOIN HU_ORG_TITLE O
                    ON O.TITLE_ID = L.ID
                  LEFT JOIN OT_OTHER_LIST GRP
                    ON L.TITLE_GROUP_ID = GRP.ID
                 WHERE L.ACTFLG = 'A'
                   AND O.ACTFLG = 'A'
                   AND O.ORG_ID = P_ORG_ID2
                 ORDER BY NLSSORT(DECODE(P_LANG,
                                         'vi-VN',
                                         L.NAME_VN,
                                         L.NAME_EN),
                                  'NLS_SORT=vietnamese'));
    END IF;
  END;
  PROCEDURE INSERT_CHOSEN_ORG(P_USERNAME   IN NVARCHAR2,
                              P_ORGID      IN NUMBER,
                              P_ISDISSOLVE IN NUMBER) IS
  BEGIN
    DELETE SE_CHOSEN_ORG E WHERE UPPER(E.USERNAME) = UPPER(P_USERNAME);
    COMMIT;
  
    INSERT INTO SE_CHOSEN_ORG E
      (SELECT ORG_ID, UPPER(P_USERNAME)
         FROM TABLE(TABLE_ORG_RIGHT(UPPER(P_USERNAME),
                                    P_ORGID,
                                    NVL(P_ISDISSOLVE, 0))));
  END;

  PROCEDURE INSERT_CHOSEN_ORG2(P_USERNAME IN VARCHAR2, P_ORG_ID IN CLOB) IS
    P_RETURN NUMBER;
    PV_1     CLOB;
    PV_2     VARCHAR2(4000);
    V_INT    NUMBER;
  BEGIN
    P_RETURN := 0;
    V_INT    := 0;
    PV_1     := P_ORG_ID || ',';
  
    DELETE SE_CHOSEN_ORG E WHERE UPPER(E.USERNAME) = UPPER(P_USERNAME);
    COMMIT;
  
    FOR I IN 1 .. LENGTH(PV_1) LOOP
      IF V_INT = 699 THEN
        V_INT := V_INT + 1;
      END IF;
      PV_2 := SUBSTR(PV_1, 1, INSTR(PV_1, ',') - 1);
    
      PV_1 := SUBSTR(PV_1, INSTR(PV_1, ',') + 1, LENGTH(PV_1));
      IF LENGTH(PV_2) > 0 THEN
        INSERT INTO SE_CHOSEN_ORG VALUES (PV_2, UPPER(P_USERNAME));
        V_INT := V_INT + 1;
      END IF;
      IF PV_1 IS NULL THEN
        P_RETURN := 1;
        EXIT;
      END IF;
    END LOOP;
    COMMIT;
  END;

  PROCEDURE INSERT_CHOSEN_EMP_3B(P_USERNAME    IN NVARCHAR2,
                                 P_EMPLOYEE_ID IN NUMBER) IS
  BEGIN
    DELETE SE_CHOSEN_EMP_3B E WHERE UPPER(E.USERNAME) = UPPER(P_USERNAME);
    COMMIT;
  
    INSERT INTO SE_CHOSEN_EMP_3B E
      (SELECT E.ID, UPPER(P_USERNAME)
         FROM HU_EMPLOYEE E
       CONNECT BY NOCYCLE PRIOR E.EMPLOYEE_3B_ID = E.ID
        START WITH E.ID = P_EMPLOYEE_ID);
  END;
  PROCEDURE GET_RC_PROGRAM_EXAMS(P_RC_PROGRAM_ID IN NUMBER,
                                 P_ISBLANK       IN NUMBER,
                                 P_LANG          IN VARCHAR,
                                 P_CUR           OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.NAME
          FROM RC_PROGRAM_EXAMS L
         WHERE L.RC_PROGRAM_ID = P_RC_PROGRAM_ID
         ORDER BY L.EXAMS_ORDER;
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID, L.NAME
                  FROM RC_PROGRAM_EXAMS L
                 WHERE L.RC_PROGRAM_ID = P_RC_PROGRAM_ID
                 ORDER BY L.EXAMS_ORDER);
    END IF;
  END;
   PROCEDURE GET_TR_COURSE(P_ISBLANK IN NUMBER,
                      P_LANG    IN VARCHAR,
                      P_CUR     OUT CURSOR_TYPE) IS
  BEGIN
    IF P_ISBLANK = 0 THEN
      OPEN P_CUR FOR
        SELECT L.ID, L.CODE, L.NAME
          FROM TR_COURSE L
         WHERE L.ACTFLG = '-1'
         ORDER BY L.TR_PROGRAM_GROUP;
    ELSE
      OPEN P_CUR FOR
        SELECT NULL ID, NULL CODE, NULL NAME
          FROM DUAL
        UNION ALL
        SELECT *
          FROM (SELECT L.ID,
                       L.CODE, 
                       L.NAME
                  FROM TR_COURSE L
                 WHERE L.ACTFLG = '-1'
                 ORDER BY L.TR_PROGRAM_GROUP);
    END IF;
  END; 
  
    PROCEDURE GET_HU_DATA_DYNAMIC_CONTRACT(P_ID               IN CLOB,
                                P_TEMPLATE_TYPE_ID IN NUMBER,
                                P_FOLDERNAME       OUT NVARCHAR2,
                                P_CUR              OUT CURSOR_TYPE) IS
    PV_VIEWNAME   VARCHAR2(255);
    PV_FOLDERNAME VARCHAR2(255);
  BEGIN
    SELECT E.FOLDER_NAME, E.VIEW_NAME
      INTO PV_FOLDERNAME, PV_VIEWNAME
      FROM HU_TEMPLATE_TYPE E
     WHERE E.ID = P_TEMPLATE_TYPE_ID;
    P_FOLDERNAME := TO_CHAR(PV_FOLDERNAME);
    OPEN P_CUR FOR 'SELECT * FROM ' || PV_VIEWNAME || ' WHERE ''' || '|' || P_ID || '|' || ''' LIKE  ''%|'' || ID || ''|%''';
  
  END;

END PKG_COMMON_LIST;
