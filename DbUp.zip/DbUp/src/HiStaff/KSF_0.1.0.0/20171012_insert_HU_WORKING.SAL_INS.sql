﻿ALTER TABLE hu_working ADD SAL_INS NUMBER(38) 
/
comment on column HU_WORKING.SAL_INS is 'Muc luong dong bao hiem'