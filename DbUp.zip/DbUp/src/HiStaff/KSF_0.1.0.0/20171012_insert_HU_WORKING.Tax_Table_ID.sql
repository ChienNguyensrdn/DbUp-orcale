﻿ALTER TABLE hu_working ADD TAX_TABLE_ID NUMBER(38) 
/
comment on column HU_WORKING.TAX_TABLE_ID is 'ID bieu thue'