﻿ALTER TABLE hu_working ADD ALLOWANCE_TOTAL NUMBER(38) 
/
comment on column HU_WORKING.ALLOWANCE_TOTAL is 'Tong cac loai phu cap'