﻿ insert into ot_other_list_type (id,
                                   code,
                                   name,
                                   actflg,
                                   group_id)
                                   values (((select max(id) from ot_other_list_type)+1),
                                   'TAX_TABLE',
                                   N'Biểu thuế',
                                   'A',
                                   3                                    )